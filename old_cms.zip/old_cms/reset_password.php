<?php require_once "blog_header.php"; ?>
<?php require_once "admin/includes/init.php";?>
<?php

global $database;
if (isset($_POST['submit'])) {
$email = $_POST['email'];
$query  = $database->query("SELECT * FROM users WHERE user_email = '$email'");

if(mysqli_num_rows($query) == 1){
$user = $query->fetch_array(MYSQLI_ASSOC);
$to = "sauciuctamara2@gmail.com";
$subject = "wow";
$message = "Your password is " . $user['user_password'];
$header = "recover password";

mail($to, $subject, $message, $header);
       

echo $user['user_password'];




}


}

?>
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-md-10 col-lg-8 col-xl-7">
            <section id="login">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-6 col-xs-offset-3">
                            <div class="form-wrap">
                                <h1>Reset your password</h1>
                                <br>
                                <form role="form" action="reset_password.php" method="post" id="login-form" autocomplete="off">
                                    <div class="form-group">
                                        <label for="email" class="sr-only">Email</label>
                                        <input type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com" autocomplete="on" value=<?php if (isset($email)) echo $email; ?>>
                                        <?php
                                        if (isset($error['email'])) echo "<p>{$error['email']}</p>";
                                        ?>
                                    </div>
                                    <br>
                                    <input type="submit" name="submit" id="btn-login" class="btn btn-primary" value="Submit" >
                                </form>
                            </div>
                        </div> <!-- /.col-xs-12 -->
                    </div> <!-- /.row -->
                </div> <!-- /.container -->
            </section>
        </div>
    </div>
</div>
<?php include "blog_footer.php"; ?>