<?php


$connection = mysqli_connect('localhost','sauciuct_demo_cms_username','yQ%A8biW4*g&','sauciuct_demo_cms_db');
// if($connection) echo "ok";
// else echo "nu";

?>