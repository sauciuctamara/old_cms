<?php include "blog_header.php"; ?>


<?php

  
if (isset($_POST['submit'])) {

    $to = "sauciuctamara2@gmail.com";
    $subject = wordwrap($_POST['subject'],70);
    $message = $_POST['message'];
    $header =  $_POST['email'];

   mail($to, $subject, $message, $header );
}


?>


<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">



        <div class="col-md-10 col-lg-8 col-xl-7">

            <p>Want to get in touch? Fill out the form below to send me a message and I will get back to you as soon as possible!</p>
            <div class="my-5">
            
                <form id="contactForm" sction="cms/contact.php" method="post">
                    <div class="form-floating">
                        <input class="form-control" name="email" type="email" placeholder="Enter your email..." data-sb-validations="required,email" />
                        <label for="email">Email address</label>
                        <div class="invalid-feedback" data-sb-feedback="email:required">An email is required.</div>
                        <div class="invalid-feedback" data-sb-feedback="email:email">Email is not valid.</div>
                    </div>
                    <div class="form-floating">
                        <input class="form-control" name="subject" type="text" placeholder="Subject..." data-sb-validations="required" />
                        <label for="subject">Subject</label>
                        <div class="invalid-feedback" data-sb-feedback="subject:required">Subject is required.</div>
                    </div>
                    <div class="form-floating">
                        <textarea class="form-control" name="message" placeholder="Enter your message here..." style="height: 12rem" data-sb-validations="required"></textarea>
                        <label for="message">Message</label>
                        <div class="invalid-feedback" data-sb-feedback="message:required">A message is required.</div>
                    </div>
                 <br>
                    <button class="btn btn-primary text-uppercase " name="submit" type="submit">Send</button>
                </form>
            </div>

        </div>

    </div>
</div>
<?php include "blog_footer.php"; ?>