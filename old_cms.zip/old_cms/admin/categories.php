<?php include "includes/admin_header.php"; ?>
<?php delete_category(); ?>
<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Categories</h1>

    </div>



    <!-- Content Row -->

    <div class="row">

            <div class="col-4">

                <?php add_category(); ?>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="cat_title">Add Category</label>
                        <input type="text" name="cat_title" class="form-control">
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" value="Add Category" class="btn btn-primary">
                    </div>
                </form>

                <?php //update and include query

                if (isset($_GET['edit'])) {
                    $cat_id = $_GET['edit'];
                    include "includes/update_categories.php";
                }
                ?>
            </div>

            <div class="col-6">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Category Title</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php showALLCategotries(); ?>


                    </tbody>
                </table>
            </div>




    </div>


</div>




<?php include "includes/admin_footer.php"; ?>