 <?php include "includes/admin_header.php"; ?>


 <!-- Begin Page Content -->
 <div class="container-fluid">


     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">USERS</h1>

     </div>

     <!-- Content Row -->
     <div class="row">

         <?php

            if (isset($_GET['source'])) {
                $source = $_GET['source'];
            } else $source = "";

            switch ($source) {
                case 'add_user';
                    include "includes/add_user.php";
                    break;
                case 'edit_user';
                    include "includes/edit_user.php";
                    break;
                default:
                    include "includes/view_all_users.php";
            }

            ?>

     </div>



 </div>




 <?php include "includes/admin_footer.php"; ?>