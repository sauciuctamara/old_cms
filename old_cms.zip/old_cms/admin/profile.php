<?php include "includes/admin_header.php" ?>

<?php

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $query = "SELECT * FROM users WHERE username = '$username'";
    $select_user_profile_query = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_user_profile_query)) {

        $user_id = $row['user_id'];
        $username = $row['username'];
        $user_password = $row['user_password'];
        $user_firstname = $row['user_firstname'];
        $user_lastname = $row['user_lastname'];
        $user_email = $row['user_email'];
        //$user_image = $row['user_image'];
        $user_role = $row['user_role'];
    }


    //UPDATE
    if (isset($_POST['update_user'])) {
        $username = $_POST['username'];
        $user_password = $_POST['user_password'];
        $user_firstname = $_POST['user_firstname'];
        $user_lastname = $_POST['user_lastname'];
        $user_email = $_POST['user_email'];

        $query = "UPDATE users SET ";
        $query .= "username = '{$username}', ";
        $query .= "user_password = '{$user_password}', ";
        $query .= "user_firstname = '{$user_firstname}', ";
        $query .= "user_lastname = '{$user_lastname}', ";
        $query .= "user_email = '{$user_email}' ";
        $query .= "WHERE username = '{$username}'";

        $update_user = mysqli_query($connection, $query);
        confirmQuery($update_user);
    }
}
?>


<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                PROFILE

            </h1>
            <div class="container">
                <form action="" method="post" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" id="" name="username" value="<?php if (isset($username)) echo $username ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">First Name </label>
                        <input type="text" class="form-control" id="" name="user_firstname" value="<?php if (isset($user_firstname)) echo $user_firstname ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Last Name </label>
                        <input type="text" class="form-control" id="" name="user_lastname" value="<?php if (isset($user_lastname)) echo $user_lastname ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="" name="user_email" value="<?php if (isset($user_email)) echo $user_email ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input autocomplete = "off" type="password" class="form-control" id="" name="user_password" value="">
                    </div>
              

                    <div class="mb-3">
                        <label class="form-label">User role : <?php echo $user_role; ?></label>
                    </div>

                    <button type="submit" class="btn btn-primary" name="update_user">Update Profile</button>

                </form>

            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>


<?php include "includes/admin_footer.php"; ?>