$(document).ready(function () {

  // summernote init
  console.log('init summernote');
  $('#summernote').summernote({
    height: 200
  })

  // -----------
  $('#selectAllBoxes').click(function (event) {
    console.log('init summernote');
    if (this.checked) {
      $('.checkBoxes').each(function () {
        this.checked = true;
      });
    } else {
      $('.checkBoxes').each(function () {
        this.checked = false;
      });
    }
  });

});


function loadUsersOnline() {
  console.log("loading usedrs count");

  $.get("get_users_online.php", function (data) {
    var result = JSON.parse(data);
    $(".usersonline").text(result.message + " : " + result.count_users_online);
  });

}

setInterval(function () {

  loadUsersOnline();


}, 5000);

