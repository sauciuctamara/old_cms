<?php

function escape($string)
{
global $connection;
mysqli_real_escape_string($connection,trim($string));
}


function add_category()
{
    global $connection;
    // Ca sa coletez datele din formular si sa le pun in tabelul din baza de date 
    if (isset($_POST['submit'])) {

        $cat_title = $_POST['cat_title'];

        if (empty($cat_title))
            echo "you have to write something";

        else {
            $insert_query = "INSERT INTO categories (cat_title) VALUE ('$cat_title')";
            $result = mysqli_query($connection, $insert_query);

            if (!$result)  die("ERROR. Please try again " . mysqli_error($connection));
        }
    }
}

function delete_category()
{
    global $delete_id;
    global $connection;
    if (isset($_GET['delete']))
        $delete_id = $_GET['delete'];
    $query = "DELETE FROM categories WHERE cat_id = $delete_id";
    mysqli_query($connection, $query);
}

function showALLCategotries()
{
    //find all categories query
    //Ca sa adaug in tabelul din pagina de admin/categories.php rezultatul obtinut mai sus
    global $connection;
    $query = "SELECT * FROM categories";
    $select_categories = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_categories)) {
        $cat_id = $row['cat_id'];
        $cat_title = $row['cat_title'];
        echo "<tr>";
        echo "<td>{$cat_id}</td>";
        echo "<td>{$cat_title}</td>";
        echo "<td><a href='categories.php?edit={$cat_id}'>EDIT</a></td>";
        echo "<td><a href='categories.php?delete={$cat_id}'>DELETE</a></td>";
        echo "<tr>";
    }
}

function delete_post()
{

    global $delete_post_id;
    global $connection;
    if (isset($_GET['delete']))
        $delete_post_id = $_GET['delete'];
    $query = "DELETE FROM posts WHERE post_id = $delete_post_id";
    mysqli_query($connection, $query);
}

function confirmQuery($result)
{
    global $connection;
    if (!$result) {
        die("QUERY FAILED  " . mysqli_error($connection));
    }
    // else echo "OK";
}

function limit_text($text, $limit)
{
    if (str_word_count($text, 0) > $limit) {
        $words = str_word_count($text, 2);
        $pos   = array_keys($words);
        $text  = substr($text, 0, $pos[$limit]) . '...';
    }
    return $text;
}


function comments_functions()
{

    global $connection;

    if (isset($_GET['approved'])) {
        $comment_id = $_GET['approved'];

        $query = "UPDATE comments SET comment_status = 'approved'  WHERE  comment_id = $comment_id";
        $unapproved_comment_query = mysqli_query($connection, $query);
        header('Location: comments.php');
    }
    if (isset($_GET['unapproved'])) {
        $comment_id = $_GET['unapproved'];

        $query = "UPDATE comments SET comment_status = 'unapproved'  WHERE  comment_id = $comment_id";
        $unapproved_comment_query = mysqli_query($connection, $query);
        header('Location: comments.php');
    }

    if (isset($_GET['delete'])) {
        $comment_id = $_GET['delete'];

        $query = "DELETE FROM comments WHERE comment_id = $comment_id";
        $delete_comment_query = mysqli_query($connection, $query);
        header('Location: comments.php');
    }
}


function showAllComments()
{
    global $connection;
    $query = "SELECT * FROM comments";
    $select_comments = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_comments)) {
        $comment_id = $row['comment_id'];
        $comment_post_id = $row['comment_post_id'];
        $comment_author = $row['comment_author'];
        $comment_content = $row['comment_content'];
        $comment_email = $row['comment_email'];
        $comment_status = $row['comment_status'];
        $comment_date = $row['comment_date'];

        echo "<tr>";
        echo "<td>$comment_id</td>";
        echo "<td>$comment_author</td>  ";
        echo "<td>$comment_content</td>";
        echo "<td>$comment_email</td>";
        echo "<td>$comment_status</td>";

        $query = "SELECT * FROM posts WHERE post_id = $comment_post_id";
        $select_post_id_query = mysqli_query($connection, $query);
        confirmQuery($select_post_id_query);

        while ($row = mysqli_fetch_assoc($select_post_id_query)) {
            $post_id = $row['post_id'];
            $post_title = $row['post_title'];
            echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
        }
        echo "<td>$comment_date</td> ";
        echo "<td><a href='comments.php?approved=$comment_id'>Approve</a></td>";
        echo "<td><a href='comments.php?unapproved=$comment_id'>Unapprove</a></td>";
        echo "<td><a href='comments.php?delete=$comment_id'>DELETE</a></td>";
        echo "</tr>";
    }
}

function checkbox_posts()
{
   global $connection;
    if (isset($_POST['checkBoxArray'])) {
        foreach ($_POST['checkBoxArray'] as $checkBoxValue) {
            $bulk_options = $_POST['bulk_options'];

            switch ($bulk_options) {
                case 'published':
                    $query = "UPDATE posts SET post_status = 'published' WHERE post_id = $checkBoxValue";
                    $bulk_publish = mysqli_query($connection, $query);
                    break;
                case 'draft':
                    $query = "UPDATE posts SET post_status = 'draft' WHERE post_id = $checkBoxValue";
                    $bulk_draft = mysqli_query($connection, $query);
                    break;
                case 'delete':
                    $query = "DELETE FROM posts WHERE post_id = $checkBoxValue";
                    $bulk_delete = mysqli_query($connection, $query);
                    break;

                case 'clone':
                    $query = "SELECT * FROM posts WHERE post_id = $checkBoxValue";
                    $select_all_posts_query = mysqli_query($connection, $query);
                    while ($row = mysqli_fetch_assoc($select_all_posts_query)) {
                        $post_author = $row['post_author'];
                        $post_title = $row['post_title'];
                        $post_category_id = $row['post_category_id'];
                        $post_status = $row['post_status'];
                        $post_image = $row['post_image'];
                        $post_tags = $row['post_tags'];
                        $post_content = $row['post_content'];
                        // $post_comment_count = $row['post_comment_count'];
                        //$post_date = $row['post_date'];

                    }
                    $query = "INSERT INTO posts (post_title, post_author, post_status, post_date, post_image, post_category_id, post_content, post_tags) ";
                    $query .= "VALUES ('$post_title', '$post_author', '$post_status', now(), '$post_image','$post_category_id', '$post_content', '$post_tags')";
                    $copy_query = mysqli_query($connection, $query);
                    if (!$copy_query) die("QUERY FAILED  " . mysqli_error($connection));
                    $post_id = mysqli_insert_id($connection);
                    break;

                case 'delete_post_views':
                    $query = "UPDATE posts SET post_view_count = 0 WHERE post_id = $checkBoxValue";
                    $bulk_delete_views = mysqli_query($connection, $query);
                    break;
            }
        }
    }
}

function insert_post_data_in_table()
{


    global $connection;
    $query = "SELECT * FROM posts ORDER BY post_id DESC";
    $select_posts = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_posts)) {
        $post_id = $row['post_id'];
        $post_author = $row['post_author'];
        $post_title = $row['post_title'];
        $post_category_id = $row['post_category_id'];
        $post_status = $row['post_status'];
        $post_image = $row['post_image'];
        $post_date = $row['post_date'];
        $post_tags = $row['post_tags'];
        //  $post_comment_count = $row['post_comment_count'];
        $post_view_count = $row['post_view_count'];
        $post_content = $row['post_content'];
        $post_content = limit_text($post_content, 10);

        echo "<tr>";
        echo "<td><input class='checkBoxes' type='checkbox' name='checkBoxArray[]' value='$post_id '></td>";
        echo "<td>$post_id</td>";
        echo "<td>$post_title</td>";
        echo "<td>$post_author</td>";

        $query = "SELECT * FROM categories WHERE cat_id = $post_category_id";
        $select_categories_id = mysqli_query($connection, $query);
        confirmQuery($select_categories_id);
        while ($row = mysqli_fetch_assoc($select_categories_id)) {
            $cat_id = $row['cat_id'];
            $cat_title = $row['cat_title'];
            echo "<td>$cat_title</td>";
        }

        echo "<td><img src='../images/$post_image' width='200' alt='alt image'></td> ";
        echo "<td>$post_content</td>";
        echo "<td>$post_tags</td>";

        $query = "SELECT * FROM comments WHERE comment_post_id = $post_id";
        $send_comment_query = mysqli_query($connection, $query);

        //$row = mysqli_fetch_assoc($send_comment_query);
        //$comment_id = $row['comment_id'];

        $comments_count = mysqli_num_rows($send_comment_query);

        echo "<td><a href='post_comments.php?id={$post_id}'>$comments_count</a></td>";

        echo "<td>$post_view_count</td>";
        echo "<td>$post_date</td> ";
        echo "<td>$post_status</td>";
        echo "<td><a href='../post.php?p_id={$post_id}'>VIEW POST</a></td>";
        echo "<td><a href='posts.php?source=edit_post&p_id={$post_id}'>EDIT</a></td>";
        echo "<td><a rel='$post_id' href='javascript:void(0)' class='delete_link'>DELETE</a></td>";
        // echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete?');\" href='posts.php?delete={$post_id}'>DELETE</a></td>";
        echo "</tr>";
    }

    if (isset($_GET['edit']))
        include "includes/update_post.php";
}

function edit_and_update_post()
{
    global $connection;

    //EDIT
    if (isset($_GET['p_id'])) {
        $post_id = $_GET['p_id'];
        $query = "SELECT * FROM posts WHERE post_id = $post_id";
        $select_post_id = mysqli_query($connection, $query);
        while ($row = mysqli_fetch_assoc($select_post_id)) {
            $post_author = $row['post_author'];
            $post_title = $row['post_title'];
            $post_category_id = $row['post_category_id'];
            $post_status = $row['post_status'];
            $post_image = $row['post_image'];
            $post_tags = $row['post_tags'];
            $post_content = $row['post_content'];
            //$post_comment_count = $row['post_comment_count'];
            // $post_date = $row['post_date'];
        }
    }
    //UPDATE
    if (isset($_POST['update_post'])) {

        $post_author = $_POST['post_author'];
        $post_title = $_POST['post_title'];
        $post_category_id = $_POST['post_category_id'];
        $post_status = $_POST['post_status'];

        $post_image = $_FILES['image']['name'];
        $post_img_temp = $_FILES['image']['tmp_name'];

        $post_tags = $_POST['post_tags'];
        $post_content = $_POST['post_content'];
        // $post_date = date('d-m-y');
        // $post_comment_count = $_POST['$post_comment_count'];

        move_uploaded_file($post_img_temp, "../images/$post_image");
        if (empty($post_image)) {
            $query = "SELECT * FROM posts WHERE post_id = $post_id";
            $select_image = mysqli_query($connection, $query);

            while ($row = mysqli_fetch_assoc($select_image)) {
                $post_image = $row['post_image'];
            }
        }
        $query = "UPDATE posts SET ";
        $query .= "post_title = '{$post_title}', ";
        $query .= "post_category_id = '{$post_category_id}', ";
        $query .= "post_author='{$post_author}', ";
        $query .= "post_date=now(), ";
        $query .= "post_image='{$post_image}', ";
        $query .= "post_content = '{$post_content}', ";
        $query .= "post_status = '{$post_status}', ";
        $query .= "post_tags= '{$post_tags}' ";
        $query .= "WHERE post_id = $post_id";

        $update_post = mysqli_query($connection, $query);
        confirmQuery($update_post);
        echo "<p class = 'bg-success'>Post Updated: <a href='../post.php?p_id={$post_id}'>View post</a> or <a href='posts.php'>Edit other posts</a></p>";
    }
}

function post_comments_functions()
{

    global $connection;

    if (isset($_GET['approved'])) {
        $comment_id = $_GET['approved'];

        $query = "UPDATE comments SET comment_status = 'approved'  WHERE  comment_id = $comment_id";
        $unapproved_comment_query = mysqli_query($connection, $query);
        header("Location: post_comments.php?id=" . $_GET['id'] . "");
    }
    if (isset($_GET['unapproved'])) {
        $comment_id = $_GET['unapproved'];

        $query = "UPDATE comments SET comment_status = 'unapproved'  WHERE  comment_id = $comment_id";
        $unapproved_comment_query = mysqli_query($connection, $query);
        header("Location: post_comments.php?id=" . $_GET['id'] . "");
    }

    if (isset($_GET['delete'])) {
        $comment_id = $_GET['delete'];

        $query = "DELETE FROM comments WHERE comment_id = $comment_id";
        $delete_comment_query = mysqli_query($connection, $query);
        header("Location: post_comments.php?id=" . $_GET['id'] . "");
    }
}

function showPostComments()
{
    global $connection;
    $post_id = $_GET['id'];
    $query = "SELECT * FROM comments WHERE comment_post_id = $post_id ";
    $select_comments = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($select_comments)) {
        $comment_id = $row['comment_id'];
        $comment_post_id = $row['comment_post_id'];
        $comment_author = $row['comment_author'];
        $comment_content = $row['comment_content'];
        $comment_email = $row['comment_email'];
        $comment_status = $row['comment_status'];
        $comment_date = $row['comment_date'];

        echo "<tr>";
        echo "<td>$comment_id</td>";
        echo "<td>$comment_author</td>  ";
        echo "<td>$comment_content</td>";
        echo "<td>$comment_email</td>";
        echo "<td>$comment_status</td>";

        $query = "SELECT * FROM posts WHERE post_id = $comment_post_id";
        $select_post_id_query = mysqli_query($connection, $query);
        confirmQuery($select_post_id_query);

        while ($row = mysqli_fetch_assoc($select_post_id_query)) {
            $post_id = $row['post_id'];
            $post_title = $row['post_title'];
            echo "<td><a href='../post.php?p_id=$post_id'>$post_title</a></td>";
        }
        echo "<td>$comment_date</td> ";
        echo "<td><a href='post_comments.php?approved=$comment_id&id=" . $_GET['id'] . "'>Approve</a></td>";
        echo "<td><a href='post_comments.php?unapproved=$comment_id&id=" . $_GET['id'] . "'>Unapprove</a></td>";
        echo "<td><a href='post_comments.php?delete=$comment_id&id=" . $_GET['id'] . "'>DELETE</a></td>";
        echo "</tr>";
    }
}


?>