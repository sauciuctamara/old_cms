<?php ob_start(); ?>
<?php include "includes/admin_header.php"; ?>


<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">COMMENTS</h1>

    </div>
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Id</th>
                <th>Author</th>
                <th>Comment</th>
                <th>Email</th>
                <th>Status</th>
                <th>In Response to</th>
                <th>Date</th>
                <th>Approve</th>
                <th>Unapprove</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>

            <?php showAllComments(); ?>

        </tbody>
    </table>

    <?php comments_functions(); ?>

</div>

<?php include "includes/admin_footer.php"; ?>