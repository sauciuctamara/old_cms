<?php global $connection;

//EDIT
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $query = "SELECT * FROM users WHERE user_id = $user_id";
    $select_user_query = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($select_user_query)) {
        $username = $row['username'];
        $user_firstname = $row['user_firstname'];
        $user_lastname = $row['user_lastname'];
        $user_email = $row['user_email'];
        $user_role = $row['user_role'];
    }

    //UPDATE
    if (isset($_POST['update_user'])) {

        $username = $_POST['username'];
        $user_password = $_POST['user_password'];
        $user_firstname = $_POST['user_firstname'];
        $user_lastname = $_POST['user_lastname'];
        $user_email = $_POST['user_email'];
        $user_role = $_POST['user_role'];


        $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 12));

        $query = "UPDATE users SET ";
        $query .= "username = '{$username}', ";
        $query .= "user_password = '{$hashed_password}', ";
        $query .= "user_firstname = '{$user_firstname}', ";
        $query .= "user_lastname = '{$user_lastname}', ";
        $query .= "user_email = '{$user_email}', ";
        $query .= "user_role = '{$user_role}' ";
        $query .= "WHERE user_id = $user_id";

        $update_user = mysqli_query($connection, $query);
        confirmQuery($update_user);
        echo "<p class = 'bg-success'>User Updated: <a href='users.php'>  View all users</a></p>";
    }
} else {
    header("Location: index.php");
}

?><div class="container">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="mb-3"><label class="form-label">Username</label><input type="text" class="form-control" id="" name="username" value="<?php if (isset($username)) echo $username ?>"></div>
        <div class="mb-3"><label class="form-label">First Name </label><input type="text" class="form-control" id="" name="user_firstname" value="<?php if (isset($user_firstname)) echo $user_firstname ?>"></div>
        <div class="mb-3"><label class="form-label">Last Name </label><input type="text" class="form-control" id="" name="user_lastname" value="<?php if (isset($user_lastname)) echo $user_lastname ?>"></div>
        <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" id="" name="user_email" value="<?php if (isset($user_email)) echo $user_email ?>"></div>
        <div class="mb-3"><label class="form-label">Password</label><input autocomplete = "off" type="password" class="form-control" id="" name="user_password" value=""></div>
        <div class="mb-3"><label class="form-label">User Role</label><br><select name="user_role" id="">
                <option value="<?php echo $user_role; ?>"><?php echo $user_role; ?></option>
                <?php

                if ($user_role == 'admin')
                    echo "<option value= 'subscriber'>subscriber</option>";

                else  echo " <option value = 'admin'>admin</option>";

                ?>
            </select></div>
        <div class="mb-3"><label for="user_image" class="form-group">User Image</label><input type="file" name="image"></div><br><button type="submit" class="btn btn-primary" name="update_user">Update</button>
    </form>
</div>