<?php
global $connection;

//EDIT
if (isset($_GET['p_id']))
    $post_id = $_GET['p_id'];
$query = "SELECT * FROM posts WHERE post_id = $post_id";
$select_post_id = mysqli_query($connection, $query);
while ($row = mysqli_fetch_assoc($select_post_id)) {
    $post_author = $row['post_author'];
    $post_title = $row['post_title'];
    $post_category_id = $row['post_category_id'];
    $post_status = $row['post_status'];
    $post_image = $row['post_image'];
    $post_tags = $row['post_tags'];
    $post_content = $row['post_content'];
    $post_comment_count = $row['post_comment_count'];
    $post_date = $row['post_date'];
}
//UPDATE
if (isset($_POST['update_post'])) {

    $post_author = $_POST['post_author'];
    $post_title = $_POST['post_title'];
    $post_category_id = $_POST['post_category_id'];
    $post_status = $_POST['post_status'];

    $post_image = $_FILES['image']['name'];
    $post_img_temp = $_FILES['image']['tmp_name'];

    $post_tags = $_POST['post_tags'];
    $post_content = $_POST['post_content'];
    // $post_date = date('d-m-y');
    // $post_comment_count = $_POST['$post_comment_count'];

    move_uploaded_file($post_img_temp, "../images/$post_image");
    if (empty($post_image)) {
        $query = "SELECT * FROM posts WHERE post_id = $post_id";
        $select_image = mysqli_query($connection, $query);

        while ($row = mysqli_fetch_assoc($select_image)) {
            $post_image = $row['post_image'];
        }
    }
    $query = "UPDATE posts SET ";
    $query .= "post_title = '{$post_title}', ";
    $query .= "post_category_id = '{$post_category_id}', ";
    $query .= "post_author='{$post_author}', ";
    $query .= "post_date=now(), ";
    $query .= "post_image='{$post_image}', ";
    $query .= "post_content = '{$post_content}', ";
    $query .= "post_status = '{$post_status}', ";
    $query .= "post_tags= '{$post_tags}' ";
    $query .= "WHERE post_id = $post_id";

    $update_post = mysqli_query($connection, $query);
    confirmQuery($update_post);
    echo "<p class = 'bg-success'>Post Updated: <a href='../post.php?p_id={$post_id}'>View post</a> or <a href='posts.php'>Edit other posts</a></p>";
}
//edit_and_update_post();

?>


<div class="container">
    <form action="" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label class="form-label">Post Title</label>
            <input value="<?php if (isset($post_title)) echo $post_title ?>" type="text" name="post_title" class="form-control">
        </div><br>
        <div class="mb-3">
            <label class="form-label">Post Category</label>

            <select name="post_category_id" id="">

                <?php

                $query = "SELECT * FROM categories";
                $select_categories = mysqli_query($connection, $query);

                confirmQuery($select_categories);

                while ($row = mysqli_fetch_assoc($select_categories)) {
                    $cat_id = $row['cat_id'];
                    $cat_title = $row['cat_title'];

                    echo "<option value ='$cat_id'>$cat_title<?option>";
                }
                ?>

            </select>
        </div><br>
        <div class="mb-3">
            <label class="form-label">Post Author</label>

            <select name="post_author" id="">

                <?php

                $query = "SELECT * FROM users";
                $select_post_author = mysqli_query($connection, $query);

                confirmQuery($select_post_author);
                while ($row = mysqli_fetch_assoc($select_post_author)) {

                    $username = $row['username'];

                    echo "<option value ='$username'>$username<?option>";
                }
                ?>

                <input value="<?php if (isset($post_author)) echo $post_author ?>" type="text" name="post_author" class="form-control">
        </div><br>

        <div class="mb-3">
            <label class="form-label">Post Tags</label>
            <input value="<?php if (isset($post_tags)) echo $post_tags ?>" type="text" name="post_tags" class="form-control">
        </div><br>
        <div class="mb-3">
            <label for="summernote" class="form-label">Post Content</label>
            <textarea type="text" class="form-control" id="summernote" name="post_content"><?php if (isset($post_content)) echo $post_content ?></textarea>
        </div><br>
        <div class="mb-3">
            <label class="form-label">Post Status</label>

            <select name="post_status" id="">
                <option value='<?php $post_status ?>'><?php echo "$post_status"; ?></option>
                <?php

                if ($post_status == 'published')
                    echo "<option value='draft'>draft</option>";
                else echo "<option value='published'>published</option>";
                ?>

            </select>


            <!-- <input value="<?php if (isset($post_status)) echo $post_status ?>" type="text" name="post_status" class="form-control"> -->
        </div>
        <br>
        <div class="mb-3">
            <label for="post_image" class="form-group">Post Image</label>
            <br>
            <img src="../images/<?php echo $post_image ?>" width="150" alt="">
            <br><br>

            <input type="file" name="image">
        </div>

        <br>
        <button type="submit" class="btn btn-primary" name="update_post">Update Post</button>

    </form>

</div>