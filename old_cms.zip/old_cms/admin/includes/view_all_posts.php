<?php include "delete_modal.php"; ?>
<?php delete_post(); ?>

<?php checkbox_posts(); ?>

<form action="" method="post">
    <table class="table table-bordered table-hover">
        <div class="row">

            <div class="col" id="bulkOptionContainer">
                <select class="form-control" name="bulk_options" id="">
                    <option value="">Select Option</option>
                    <option value="published">Publish</option>
                    <option value="draft">Draft</option>
                    <option value="delete">Delete</option>
                    <option value="clone">Clone</option>
                    <option value="delete_post_views">Delete Post Views</option>
                </select>
                <br>
            </div>
            <div class="col">

                <input type="submit" name="submit" class="btn btn-success" value="Apply">
                <a class="btn btn-primary" href="posts.php?source=add_post"> Add new</a>

            </div>
        </div>
        <thead>
            <tr>
                <th><input id="selectAllBoxes" type="checkbox"></th>
                <th>Id</th>
                <th>Title</th>
                <th>Author</th>
                <th>Category</th>
                <th>Image</th>
                <th>Content</th>
                <th>Tags</th>
                <th>Comments</th>
                <th>Post Views</th>
                <th>Date</th>
                <th>Status</th>
                <th>View Post</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>

            <?php insert_post_data_in_table(); ?>

        </tbody>
    </table>

</form>


<script>
    $(document).ready(function() {

        $(".delete_link").on('click', function() {

            var id = $(this).attr("rel");
            var delete_url = "post.php?delete={$post_id}" + id + " ";
            $(".delete_modal_link").attr("href", delete_url);
            $("#myModal").modal("show");

        });

    });
</script>