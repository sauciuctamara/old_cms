<?php

if (isset($_POST['create_user'])) {
    global $connection;
    $username = $_POST['username'];
    $user_password = $_POST['user_password'];
    $user_firstname = $_POST['user_firstname'];
    $user_lastname = $_POST['user_lastname'];
    $user_email = $_POST['user_email'];
    $user_role = $_POST['user_role'];
    $user_image = $_FILES['image']['name'];
    $user_img_temp = $_FILES['image']['tmp_name'];
    $user_date = date('d-m-y');

    move_uploaded_file($user_img_temp, "../images/$user_image");

    //$user_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10));

    $query = "INSERT INTO users (username, user_password, user_firstname, user_lastname, user_email, user_role, user_date)  ";
    $query .= "VALUES ('$username', '$user_password', '$user_firstname', '$user_lastname', '$user_email', '$user_role' , now()) ";

    $create_user_query = mysqli_query($connection, $query);
    confirmQuery($create_user_query);

    echo "<p class = 'bg-success'>User Created: <a href='users.php'>  View all users</a></p>";
}
?>


<div class="container">
    <form action="" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" id="" name="username">
        </div>
        <div class="mb-3">
            <label class="form-label">First Name </label>
            <input type="text" class="form-control" id="" name="user_firstname">
        </div>
        <div class="mb-3">
            <label class="form-label">Last Name </label>
            <input type="text" class="form-control" id="" name="user_lastname">
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" id="" name="user_email">
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" id="" name="user_password">
        </div>
        <!-- <div class="mb-3">
            <label class="form-label">Post Content</label>
            <textarea type="text" class="form-control" id="" name=""></textarea>
        </div> -->

        <div class="mb-3">
            <label class="form-label">User Role</label>
            <br>
            <select name="user_role" id="">
                <option value="subscriber">Select Option</option>
                <option value="admin">Admin</option>
                <option value="subscriber">Subscriber</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="user_image" class="form-group">User Image</label>
            <input type="file" name="image">
        </div>

        <br>
        <button type="submit" class="btn btn-primary" name="create_user">Submit</button>

    </form>

</div>