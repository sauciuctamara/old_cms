

<div class="container"><?php

if (isset($_POST['create_post'])) {
    global $connection;

    $post_author = $_POST['post_author'];
    $post_title = $_POST['post_title'];
    $post_status = $_POST['post_status'];
    $post_category_id = $_POST['post_category_id'];
    $post_image = $_FILES['image']['name'];
    $post_img_temp = $_FILES['image']['tmp_name'];
    $post_tags = $_POST['post_tags'];
    $post_content = $_POST['post_content'];
    $post_date = date('d-m-y');

    move_uploaded_file($post_img_temp, "../images/$post_image");

    $query = "INSERT INTO posts (post_title, post_author, post_status, post_date, post_image, post_category_id, post_content, post_tags) ";
    $query .= "VALUES ('$post_title', '$post_author', '$post_status', now(), '$post_image','$post_category_id', '$post_content', '$post_tags')";

    $create_post_query = mysqli_query($connection, $query);
    confirmQuery($create_post_query);

    $post_id = mysqli_insert_id($connection);

    echo "<p class ='bg-success'>Post Created: <a href='../post.php?p_id={$post_id}'>View post</a> or <a href='admin/posts.php?source=add_post'>Add another post</a></p>";
}
?>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Post Title</label>
            <input type="text" class="form-control" id="" name="post_title">
        </div> <br>
        <div class="mb-3">
            <label class="form-label">Post Category</label>
            <br>
            <select name="post_category_id" id="">
                <?php
                $query = "SELECT * FROM categories";
                $select_categories = mysqli_query($connection, $query);
                while ($row = mysqli_fetch_assoc($select_categories)) {
                    $cat_id = $row['cat_id'];
                    $cat_title = $row['cat_title'];
                    echo "<option value ='$cat_id'>$cat_title</option>";
                }
                ?>
            </select>
        </div>


  <div class="mb-3">
            <label class="form-label">Users</label>
            <br>
            <select name="post_author" id="">
                <?php
                $query = "SELECT * FROM users";
                $select_users = mysqli_query($connection, $query);
                while ($row = mysqli_fetch_assoc($select_users)) {
                    $user_id = $row['user_id'];
                    $username = $row['username'];
                    echo "<option value ='$username'>$username</option>";
                }
                ?>
            </select>
        </div>




        <!-- <div class="mb-3">
            <label class="form-label">Post Author</label>
            <input type="text" class="form-control" id="" name="post_author">
        </div> -->

        <div class="mb-3">
            <label class="form-label">Post Status</label>
            <br>
            <select name="post_status" id="">
                <option value="draft">Select Option</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Post Tags</label>
            <input type="text" class="form-control" id="" name="post_tags">
        </div>
        <div class="mb-3">
            <label for="summernote" class="form-label">Post Content</label>
            <textarea type="text" class="form-control" id="summernote" name="post_content"></textarea>
        </div>
        <div class="mb-3">
            <label for="post_image" class="form-group">Post Image</label>
            <input type="file" name="image">
        </div>
        <br>
        <button type="submit" class="btn btn-primary" name="create_post">Create Post</button>

    </form>

</div>