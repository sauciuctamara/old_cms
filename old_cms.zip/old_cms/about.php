<?php include "blog_header.php"; ?>
<div class="container px-4 px-lg-5">
    <div class="row gx-4 gx-lg-5 justify-content-center">


        <div class="col-md-10 col-lg-8 col-xl-7">

           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio aut libero molestias harum ipsum nihil quibusdam sequi nesciunt cum officiis, cumque doloribus officia incidunt obcaecati saepe commodi quisquam distinctio minima.</p>
       <br>
        </div>


    </div>
</div>
<?php include "blog_footer.php"; ?>